from socket import *
from time import ctime
import threading
from enum import Enum
import struct

HOST = '127.0.0.1'# 服务器IP地址
PORT = 1234 # 服务器端口
MESSAGEBUF = 1024+8
ADDR = (HOST,PORT)

class EnumMessageType(Enum):
    common      = 1 #普通消息
    reg         = 2 # 注册消息
    login       = 3 # 登录消息
    file        = 4 # 传输文件
    picture     = 5 # 发送图片
    control     = 6 # 远控


def RecvThread(sock):
    while True:
        message = sock.recv(MESSAGEBUF)
        # 消息类型
        type, = struct.unpack("i", message[ :4 ])
        # 消息长度
        length, = struct.unpack("L", message[ 4:8 ])
        buf, = struct.unpack("%ds" % length, message[ 8:8 + length ])
        message_recv = buf.decode("gb2312")
        print(message_recv)


def main():
    clientSocket = socket(AF_INET,SOCK_STREAM)
    clientSocket.connect(ADDR)
    message = clientSocket.recv(MESSAGEBUF)
    # 消息类型
    type, = struct.unpack("i", message[:4])
    # 消息长度
    length,  = struct.unpack("L", message[4:8])
    buf,  = struct.unpack("%ds"%length,message[8:8+length])
    name  = buf.decode("gb2312")
    print("你的名字："+name)
    t = threading.Thread(target=RecvThread,args=(clientSocket,))
    t.start();
    while True:
        message = input() # 在这输入你的消息
        message = (name+"说："+message).encode("gb2312")
        message_type = EnumMessageType.common
        message_len = len(message)
        message_send = struct.pack("ll%ds"%message_len, 1, message_len, message)
        clientSocket.send(message_send)
    clientSocket.close()
    input()


if __name__ == '__main__':
    main()